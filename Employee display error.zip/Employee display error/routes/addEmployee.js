var async = require('async');
var mongoose = require('mongoose');
var express = require('express');
var Employee = require('../models/employee');
var router = express.Router();
fs = require('fs'); // writing employee data to a file 
let date_ob = new Date(); // used to timestamp employees 



async.series([

   // getID,
], function(error, results) {
    if (error) {
        console.error('Error: ' + error);
    }

    mongoose.connection.close();
    console.log('Done!');
});


router.post('/FingerPrint', function (req, res, next) {
    console.log('ID::',req.query.id);

    fs.appendFile('log.txt', "ID " +  req.query.id + " Time " + date_ob  + "\n", function (err) {
        if (err) throw err;
        console.log('Saved!');
        fs.close; 
      });

})


router.post('/addEmployees', function (req, res, next) {

    let employee = new Employee(
        {
            id: req.body.id,
            name: {

                first: req.body.firstname,
                last: req.body.lastname
            },
            image: '',
            address: {
                lines: [''],
                city: '',
                state: '',
                zip: 0000
            }
        }
    );

    employee.save(function(err){
        if(err){
            console.log('err',err);
            return res.status(500).json({
                message: 'Error in database'
            });
        }

        return res.status(200).json({
            message: 'Successflly inserted in database'
        });
    });


});



module.exports = router;




